#include "stm32f10x.h"                  
#include "OLED.h"  
#include "Standby_Show.h" 
#include "Act.h" 
#include "Serial.h" 
DataStruct ReadDat;
TimeStruct TimeData;

int main(void)
{
  OLED_Init();
	Standby_Init();
  Serial_Init();

	Act_Init();
	Face(Actinit);
	DS1302_WriteTime(); //修改时间默认关闭
 
  while(1)
	{
		
		if(Act_mode != 0x20) Act_Cmd();
		if(Act_mode == 0x21)
		{		
			      
			switch(Kind_recognition())
			 {
				 case 0x30: Act_mode = 0x06;break;
				 case 0x31: Act_mode = 0x03;break;
				 case 0x32: Act_mode = 0x05;break;
				 case 0x33: Act_mode = 0x01;break;
				 default: ;
			 }
			 Serial_SendByte(Act_mode);
					 
		}
		if(Act_mode == 0x20){
		Act_Stand();Face(Stand);Delay_ms(500);
		Act_Stretch();Delay_ms(250);
		Face(Lie);Delay_ms(2000);Act_Stand();
		Delay_ms(750);Act_Lie();Face(Actinit);Delay_ms(3000);	
		OLED_Clear();OLED_Update();
		while(Act_mode == 0x20) Standby_OLEDShow();
		}
	}
}

#include "stm32f10x.h"     // Device header
#include "Delay.h"     
#include "OLED.h"                  


#define OUT 0
#define IN 1
#define DHT11_Port GPIOB
#define DHT11_Pin GPIO_Pin_9

 

void GpioMode(uint8_t Mode)
{
 GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Pin = DHT11_Pin;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	if(Mode == OUT) GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	else GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;	
  GPIO_Init(DHT11_Port,&GPIO_InitStruct);	
}

uint8_t DHT11_Check(void)
{
 uint8_t retry = 0;//retry 是重操作的含义
  GpioMode(IN);
	
 while(GPIO_ReadInputDataBit(DHT11_Port,DHT11_Pin) && retry < 100){//等待响应低电平
   retry ++;
   Delay_us(1);	 
 };
 if(retry >= 100) return 1;
		else retry = 0;
 while(!GPIO_ReadInputDataBit(DHT11_Port,DHT11_Pin) && retry < 100){//等待DHT拉高
   retry ++;
   Delay_us(1);	 
 };
 if(retry >= 100) return 2;
 return 0;
}

void DHT11_Rst(void)
{
 GpioMode(OUT);
 GPIO_ResetBits(DHT11_Port,DHT11_Pin);
 Delay_ms(20);
 GPIO_SetBits(DHT11_Port,DHT11_Pin);
 Delay_us(30);
}
uint8_t DHT11_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitStruct.GPIO_Pin = DHT11_Pin;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(DHT11_Port,&GPIO_InitStruct);	
	GPIO_SetBits(DHT11_Port,DHT11_Pin);
  DHT11_Rst();
 return DHT11_Check();
}

uint8_t DHT11_ReadBit(void)
{
	uint8_t retry = 0;
	while(GPIO_ReadInputDataBit(DHT11_Port,DHT11_Pin) && retry < 100){//等待开始传输低电平
   retry ++;
   Delay_us(1);	 
 }
	retry = 0;
 while(!GPIO_ReadInputDataBit(DHT11_Port,DHT11_Pin) && retry < 100){//等待传输高电平
   retry ++;
   Delay_us(1);	 
 }
 Delay_us(40);	
 if(GPIO_ReadInputDataBit(DHT11_Port,DHT11_Pin) == 1) return 1;
 else return 0;
}

uint8_t DHT11_ReadByte(void)
{
 uint8_t i,B;
 B = 0;
	for(i = 0;i < 8;i ++)
	{
	 B <<= 1;
	 B |= DHT11_ReadBit();
	}
 return B;
}

uint8_t DHT11_ReadData(uint8_t *temp,uint8_t *humi)    		
{        
 	uint8_t Buf[5];								
	uint8_t i;
  DHT11_Rst();

	if(DHT11_Check() == 0)				
	{
		for(i=0;i<5;i++)						
		{
			Buf[i]=DHT11_ReadByte();			
		}
		if((Buf[0]+Buf[1]+Buf[2]+Buf[3])==Buf[4])	
		{
			*humi=Buf[0];	
				
			*temp=Buf[2];
		
		}else return 2;
	}
	else return 1;									
	return 0;	    							
}

void DHT11_Start(void)
{
	OLED_ShowString(0,0,"DHT11_Init...",OLED_8X16);
	OLED_Update();
	Delay_ms(800);
  while(DHT11_Init()) Delay_ms(1000);
	OLED_Clear();
}

void DHT11_OLED(uint8_t *temp,uint8_t *humi)
{
 	  
    DHT11_ReadData(temp,humi);
	 
		OLED_ShowImage(8,32,16,32,Temper);
		OLED_ShowNum(32,40,*temp,2,OLED_8X16);
	  OLED_ShowImage(48,40,8,16,TempC);
	  
	  OLED_ShowImage(72,32,16,32,Drip);
		OLED_ShowNum(96,40,*humi,2,OLED_8X16);
	  OLED_ShowChar(112,40,'%',OLED_8X16);
		OLED_Update(); 
	  Delay_ms(800);
}

#include "stm32f10x.h" // Device header
#include "ACT.h"
#ifndef _SERIAL_H_
#define  Image_Num 15
extern uint8_t Image_Kind;
//extern uint8_t Kind_Data[4];
void Serial_Init(void);
void Serial_SendByte(uint8_t Byte);
void Serial_SendArray(uint8_t *Array,uint16_t Length);
void Serial_SendString(char *String);
uint8_t Serial_GetRxFlag(void);
uint8_t Kind_recognition(void);
#define _SERIAL_H_
#endif

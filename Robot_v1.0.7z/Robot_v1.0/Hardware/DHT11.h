#include "stm32f10x.h"                  // Device header
#ifndef _DHT11_H
#define _DHT11_H
void GpioMode(uint8_t Mode);
uint8_t DHT11_Check(void);
uint8_t DHT11_Init(void);
uint8_t DHT11_ReadBit(void);
uint8_t DHT11_ReadByte(void);
uint8_t DHT11_ReadData(uint8_t *temp,uint8_t *humi) ;
void DHT11_Start(void);
void DHT11_OLED(uint8_t *temp,uint8_t *humi);
#endif

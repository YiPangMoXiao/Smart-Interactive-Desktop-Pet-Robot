#include "Serial.h" 
             

uint8_t Serial_RxData;
uint8_t Serial_RxFlag;
uint8_t Image_Kind = 0;

void Serial_Init(void)
{
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1  | RCC_APB2Periph_GPIOA,ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2 | RCC_APB1Periph_USART3,ENABLE);
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_2;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_3;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_11;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	
	USART_InitTypeDef USART_InitStruct;
	USART_InitStruct.USART_BaudRate = 9600;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStruct.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStruct.USART_Parity = USART_Parity_No;
	USART_InitStruct.USART_StopBits = USART_StopBits_1;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART1,&USART_InitStruct);
	USART_Init(USART2,&USART_InitStruct);
	USART_Init(USART3,&USART_InitStruct);
	
	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
	USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);
	USART_ITConfig(USART3,USART_IT_RXNE,ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStruct);
	
	NVIC_InitStruct.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStruct);
	
	NVIC_InitStruct.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStruct);
	USART_Cmd(USART1, ENABLE);
  USART_Cmd(USART2, ENABLE);
  USART_Cmd(USART3, ENABLE);
}

void Serial_SendByte(uint8_t Byte)
{
 USART_SendData(USART3,Byte); 
 while(USART_GetFlagStatus(USART3,USART_FLAG_TXE) == RESET);//标志位自动清除
}

void Serial_SendArray(uint8_t *Array,uint16_t Length)
{
 uint16_t i;
 for(i = 0;i < Length;i ++)
	{
	 Serial_SendByte(Array[i]);
	}
}
/*
需要“\r\n”才能换行
*/
void Serial_SendString(char *String)
{
 uint8_t i;
	for(i = 0;String[i] != '\0';i ++)
	{
	 Serial_SendByte(String[i]);
	}
}

uint8_t Serial_GetRxFlag()
{
 if(Serial_RxFlag == 1)
 {
  Serial_RxFlag = 0;
	return 1;
 }
 return 0;
}
/*
uint8_t Serial_GetRxData()
{
 return Serial_RxData;
}
*/
void USART1_IRQHandler()//蓝牙
{
 if(USART_GetITStatus(USART1,USART_IT_RXNE) == SET)
 {
   Act_mode = USART_ReceiveData(USART1);
	
	 s_1 = 0;
	 USART_ClearITPendingBit(USART1,USART_IT_RXNE);
 }
}

void USART2_IRQHandler()//图像
{
 if(USART_GetITStatus(USART2,USART_IT_RXNE) == SET)
 {
   Image_Kind = USART_ReceiveData(USART2);
	 Serial_RxFlag = 1;
	 USART_ClearITPendingBit(USART2,USART_IT_RXNE);
 }
}

void USART3_IRQHandler()//语音
{
 if(USART_GetITStatus(USART3,USART_IT_RXNE) == SET)
 {
   Act_mode = USART_ReceiveData(USART3);
	
	 s_1 = 0;
	 USART_ClearITPendingBit(USART3,USART_IT_RXNE);
 }
}
/* 0x30->0x34 'turn left', 'go on', 'turn right', 'banning'*/
uint8_t Kind_recognition(void)
{
 uint8_t	Kind_Data[4] = {0};
 while(1)
 {
		if(Serial_GetRxFlag() == 1) 
		{
			 switch(Image_Kind)
		 {
			 case 0x30: Kind_Data[0] ++;if(Kind_Data[0] == Image_Num){return 0x30;}break;
			 case 0x31: Kind_Data[1] ++;if(Kind_Data[1] == Image_Num){return 0x31;}break;
			 case 0x32: Kind_Data[2] ++;if(Kind_Data[2] == Image_Num){return 0x32;}break;
			 case 0x33: Kind_Data[3] ++;if(Kind_Data[3] == Image_Num){return 0x33;}break;
			 case 0x35: Kind_Data[1] ++;if(Kind_Data[1] == Image_Num){return 0x31;}break;
			 default: ;
		 }
		}
	}
}

/*第一种提高图像识别容错方法
uint8_t Kind_recognition(void)
{
	uint8_t i,KindData = 1;
	uint8_t Kind_Data[4] = {0};


 while(i < 30)
 {
  if(Serial_GetRxFlag() == 1)
	{
	 switch(Image_Kind)
	 {
		 case 0x30: Kind_Data[0] ++;break;
		 case 0x31: Kind_Data[1] ++;break;
		 case 0x32: Kind_Data[2] ++;break;
		 case 0x33: Kind_Data[3] ++;break;
		 case 0x35: Kind_Data[1] ++;break;
		 default: ;
	 }
	 i ++;
	}
 }
 KindData = Kind_Data[0];
 for(i = 1;i <= 3;i ++)
 {
	 KindData = (KindData > Kind_Data[i]) ? KindData : Kind_Data[i];
 }
 
 for(i = 0;i < 4;i ++)
 {
  if(KindData == Kind_Data[i]) 
	{
	 	 switch(i)
	 {
		 case 0: return 0x30;
		 case 1: return 0x31;
		 case 2: return 0x32;
		 case 3: return 0x33;

		 default: ;
	 }
	}	
 }

 return 1;
}
*/

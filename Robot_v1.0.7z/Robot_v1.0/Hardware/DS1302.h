#include "stm32f10x.h"                  // Device header

#ifndef _DS1302_H
#define _DS1302_H
#define CLK_Pin GPIO_Pin_12
#define DATA_Pin GPIO_Pin_13
#define CE_Pin GPIO_Pin_14
#define DS1302_Port GPIOB
#define OUT 1
#define IN 0
#define CLK_High GPIO_SetBits(DS1302_Port,CLK_Pin);
#define CLK_Low GPIO_ResetBits(DS1302_Port,CLK_Pin);
#define CE_High GPIO_SetBits(DS1302_Port,CE_Pin);
#define CE_Low GPIO_ResetBits(DS1302_Port,CE_Pin);
#define DATA_High GPIO_SetBits(DS1302_Port,DATA_Pin);
#define DATA_Low GPIO_ResetBits(DS1302_Port,DATA_Pin);
typedef struct DataStruct
{
 uint16_t yeardat;
	uint8_t  monthdat;
	uint8_t  daydat;
	uint8_t  hourdat;
	uint8_t  minutedat;
	uint8_t  seconddat;
	uint8_t  weekdat;
}DataStruct;
typedef struct TimeStruct{
 uint16_t year;
	uint8_t  month;
	uint8_t  day;
	uint8_t  hour;
	uint8_t  minute;
	uint8_t  second;
	uint8_t  week;
} TimeStruct;
extern DataStruct ReadDat;
extern TimeStruct TimeData;
void DS1302_Init(void);
void DS1302_WriteByte(uint8_t Byte);
void DS1302_WriteData(uint8_t Address,uint8_t Data);
uint8_t DS1302_ReadByte(uint8_t Address);
void DS1302_ReadData(void);
void DS1302_ReadTime(void);
void DS1302_WriteTime(void);
void DS1302_ShowTime(void);
#endif

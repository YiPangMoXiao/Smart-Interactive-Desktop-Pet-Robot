#include "stm32f10x.h"  
#include "DS1302.h"                  // Device header
#include "Delay.h"
#include "OLED.h"                  // Device header

void DS1302_Init(void)
{
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
 GPIO_InitTypeDef GPIO_InitStruct;
 GPIO_InitStruct.GPIO_Mode = 	GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin = CLK_Pin | DATA_Pin | CE_Pin;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(DS1302_Port,&GPIO_InitStruct);
	CLK_Low;
	CE_Low;

}

void IO_Mode(uint8_t Mode)
{
  GPIO_InitTypeDef GPIO_InitStruct;

	GPIO_InitStruct.GPIO_Pin = DATA_Pin;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	if(Mode == OUT) GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	  else GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(DS1302_Port,&GPIO_InitStruct);
}

void DS1302_WriteByte(uint8_t Byte)
{
 uint8_t count;
 CLK_Low;
	IO_Mode(OUT);
	
	for(count=0;count<8;count++)
		{	CLK_Low;
			if(Byte&0x01)
			{DATA_High;}
			else{DATA_Low;}//��׼���������ٷ���
			CLK_High;//����ʱ���ߣ���������
			Byte>>=1;
		}
}

void DS1302_WriteData(uint8_t Address,uint8_t Data)
{
	CE_Low;CLK_Low;Delay_us(1);
	CE_High;Delay_us(3);
	DS1302_WriteByte(Address);
	DS1302_WriteByte(Data);
  CE_Low;CLK_Low;Delay_us(3);
}
void DS1302_WriteTime(void)
{
  DS1302_WriteData(0x8e,0x00);//�ر�д����
	DS1302_WriteData(0x80,0x00);//seconds00��
	DS1302_WriteData(0x82,0x01);//minutes12��
	DS1302_WriteData(0x84,0x11);//hours20ʱ
	DS1302_WriteData(0x86,0x12);//date3��
	DS1302_WriteData(0x88,0x03);//months2��
	DS1302_WriteData(0x8a,0x06);//days������
	DS1302_WriteData(0x8c,0x25);//year2025��
	DS1302_WriteData(0x8e,0x80);//����д����
}
uint8_t DS1302_ReadByte(uint8_t Address)
{
	uint8_t i,Data = 0x00;
	IO_Mode(OUT);
	
  CE_Low;CLK_Low;Delay_us(3);
	CE_High;Delay_us(3);
	DS1302_WriteByte(Address);
	IO_Mode(IN);
	Delay_us(3);
	for(i = 0;i < 8;i ++)
	{
	  Delay_us(3);//ʹ��ƽ����һ��ʱ��
		Data>>=1;
		CLK_High;Delay_us(5);//ʹ�ߵ�ƽ����һ��ʱ��
		CLK_Low;Delay_us(30);//��ʱ14us����ȥ��ȡ��ѹ������׼ȷ
		if(GPIO_ReadInputDataBit(DS1302_Port,DATA_Pin))
		{Data=Data|0x80;}
	}
	Delay_us(2);
	CE_Low;DATA_Low;
	return Data;
}

void DS1302_ReadData(void)
{
  ReadDat.seconddat=DS1302_ReadByte(0x81);//����
	ReadDat.minutedat=DS1302_ReadByte(0x83);//����
	ReadDat.hourdat=DS1302_ReadByte(0x85);//��ʱ
	ReadDat.daydat=DS1302_ReadByte(0x87);//����
	ReadDat.monthdat=DS1302_ReadByte(0x89);//����
	ReadDat.weekdat=DS1302_ReadByte(0x8B);//������
	ReadDat.yeardat=DS1302_ReadByte(0x8D);//����
}

void DS1302_ReadTime(void)
{
	DS1302_ReadData();//BCD��ת��Ϊ10����
	TimeData.second=(ReadDat.seconddat>>4)*10+(ReadDat.seconddat&0x0f);
	TimeData.minute=((ReadDat.minutedat>>4))*10+(ReadDat.minutedat&0x0f);
	TimeData.hour=(ReadDat.hourdat>>4)*10+(ReadDat.hourdat&0x0f);
	TimeData.day=(ReadDat.daydat>>4)*10+(ReadDat.daydat&0x0f);
	TimeData.month=(ReadDat.monthdat>>4)*10+(ReadDat.monthdat&0x0f);
	TimeData.week=ReadDat.weekdat;
	TimeData.year=(ReadDat.yeardat>>4)*10+(ReadDat.yeardat&0x0f)+2000;	
}
void DS1302_ShowTime(void)
{	
		OLED_ShowNum(0,0,11,2,OLED_8X16);
		OLED_ShowChar(16,0,':',OLED_8X16); 
		OLED_ShowNum(24,0,4,2,OLED_8X16);
	  
		OLED_ShowNum(0,16,2025,4,OLED_8X16);
		OLED_ShowChar(32,16,'/',OLED_8X16);  
		OLED_ShowNum(40,16,3,2,OLED_8X16);
		OLED_ShowChar(56,16,'/',OLED_8X16);
		OLED_ShowNum(64,16,12,2,OLED_8X16);
		OLED_ShowImage(88,0,32,32,Sun);
	  OLED_Update();
	/*
    DS1302_ReadTime();
	  
		OLED_ShowNum(0,0,TimeData.hour,2,OLED_8X16);
		OLED_ShowChar(16,0,':',OLED_8X16); OLED_Update(); 	
		OLED_ShowNum(24,0,TimeData.minute,2,OLED_8X16);
	  
		OLED_ShowNum(0,16,TimeData.year,4,OLED_8X16);
		OLED_ShowChar(32,16,'/',OLED_8X16);  
		OLED_ShowNum(40,16,TimeData.month,2,OLED_8X16);
		OLED_ShowChar(56,16,'/',OLED_8X16);
		OLED_ShowNum(64,16,TimeData.day,2,OLED_8X16);
	  if(TimeData.hour >= 6 && TimeData.hour <= 17) OLED_ShowImage(88,0,32,32,Sun);
		else OLED_ShowImage(88,0,32,32,Moon);
		//���ڣ�Ĭ�Ϲر�OLED_ShowNum(0,32,TimeData.week,2,OLED_8X16);
		OLED_Update();
	*/
		/* �� ��������Ч����Ĭ�Ϲر�	
		Delay_ms(500);
	
    
		OLED_ShowNum(0,0,TimeData.hour,2,OLED_8X16);
		OLED_ShowChar(16,0,' ',OLED_8X16); OLED_Update(); 	
		OLED_ShowNum(24,0,TimeData.minute,2,OLED_8X16);
	  
		OLED_ShowNum(0,16,TimeData.year,4,OLED_8X16);
		OLED_ShowChar(32,16,'/',OLED_8X16);  
		OLED_ShowNum(40,16,TimeData.month,2,OLED_8X16);
		OLED_ShowChar(48,16,'/',OLED_8X16);
		OLED_ShowNum(56,16,TimeData.day,2,OLED_8X16);
		
		OLED_ShowNum(0,32,TimeData.week,2,OLED_8X16);
		OLED_Update();
		Delay_ms(500);
		*/
}

#include "DHT11.h"
#include "DS1302.h" 
#ifndef _STANDBY_SHOW_H
#define _STANDBY_SHOW_H

void Standby_Init(void);
void Standby_OLEDShow(void);
#endif

#include "Act.h"
 uint8_t Act_mode = 0x00 ;
/*
        (腿前甩->后甩)
 1(0->180)     2(180->0)
 
 
 3(0->180)     4(180->0)
           0()
 
 0：5 /45:10 /90:15 /135:20 /180:25 
*/
void Act_Init()
{
	PWM_Init();
	PWM_SetCompare(1,25);//-180
  PWM_SetCompare(2,5);//-0
  PWM_SetCompare(3,5);//-0
  PWM_SetCompare(4,25);//-180
	
}
void Act_Stand()//站立
{
	PWM_SetCompare(1,15);//90
  PWM_SetCompare(2,15);//90
  PWM_SetCompare(3,15);//90
  PWM_SetCompare(4,15);//90
	/*
	while(Act_mode == 0x01)
	{
	 PWM_SetCompare(0,10);//45
	 Delay_ms(200);
	 if(Act_mode != 0x01) break;
   PWM_SetCompare(0,20);//135
	 Delay_ms(200);
	 if(Act_mode != 0x01) break;
	}
	*/
}
void Act_Sit()//坐
{
	PWM_SetCompare(1,15);//90
  PWM_SetCompare(2,15);//90
  PWM_SetCompare(3,10);//45
  PWM_SetCompare(4,20);//135
	/*
	while(Act_mode == 0x02)
	{
	 PWM_SetCompare(0,10);//45
	 Delay_ms(200);
	 if(Act_mode != 0x02) break;
   PWM_SetCompare(0,20);//135
	 Delay_ms(200);
	 if(Act_mode != 0x02) break;
	}
	*/
}
void Act_Advance()//前进
{
	while(Act_mode == 0x03)
	{
	PWM_SetCompare(2,20);//135
  PWM_SetCompare(3,10);//45
		Delay_ms(200);
		if(Act_mode != 0x03) break;
  PWM_SetCompare(1,20);//135
  PWM_SetCompare(4,10);//45   
	  Delay_ms(200);
		if(Act_mode != 0x03) break;
  PWM_SetCompare(2,15);//90
  PWM_SetCompare(3,15);//90 
    Delay_ms(200);
		if(Act_mode != 0x03) break;
  PWM_SetCompare(1,15);//90
  PWM_SetCompare(4,15);//90  
    Delay_ms(200);
		if(Act_mode != 0x03) break;
  PWM_SetCompare(1,10);//45
  PWM_SetCompare(4,20);//135 		
		Delay_ms(200);
		if(Act_mode != 0x03) break;
  PWM_SetCompare(2,10);//45
  PWM_SetCompare(3,20);//135 
	  Delay_ms(200);
		if(Act_mode != 0x03) break;
  PWM_SetCompare(1,15);//90
  PWM_SetCompare(4,15);//90 
    Delay_ms(200);
		if(Act_mode != 0x03) break;
  PWM_SetCompare(2,15);//90
  PWM_SetCompare(3,15);//90 
    Delay_ms(200);
		if(Act_mode != 0x03) break;	
	}
                 
}
void Act_Back()//后退
{
	while(Act_mode == 0x04)
	{
	PWM_SetCompare(2,10);//45
  PWM_SetCompare(3,20);//135
		Delay_ms(200);
		if(Act_mode != 0x04) break;
  PWM_SetCompare(1,10);//45
  PWM_SetCompare(4,20);//135  
	  Delay_ms(200);
		if(Act_mode != 0x04) break;
  PWM_SetCompare(2,15);//90
  PWM_SetCompare(3,15);//90 
    Delay_ms(200);
		if(Act_mode != 0x04) break;
  PWM_SetCompare(1,15);//90
  PWM_SetCompare(4,15);//90  
    Delay_ms(200);
		if(Act_mode != 0x04) break;
  PWM_SetCompare(1,20);//135
  PWM_SetCompare(4,10);//45 		
		Delay_ms(200);
		if(Act_mode != 0x04) break;
  PWM_SetCompare(2,20);//135
  PWM_SetCompare(3,10);//45 
	  Delay_ms(200);
		if(Act_mode != 0x04) break;
  PWM_SetCompare(1,15);//90
  PWM_SetCompare(4,15);//90 
    Delay_ms(200);
		if(Act_mode != 0x04) break;
  PWM_SetCompare(2,15);//90
  PWM_SetCompare(3,15);//90 
    Delay_ms(200);
		if(Act_mode != 0x04) break;
	}
                 
}
void Act_TurnR()//右转
{
 while(Act_mode == 0x05)
	{
	PWM_SetCompare(2,10);//45
  PWM_SetCompare(3,10);//45
		Delay_ms(200);
		if(Act_mode != 0x05) break;
  PWM_SetCompare(1,20);//135
  PWM_SetCompare(4,20);//135  
	  Delay_ms(200);
		if(Act_mode != 0x05) break;
  PWM_SetCompare(2,15);//90
  PWM_SetCompare(3,15);//90 
    Delay_ms(200);
		if(Act_mode != 0x05) break;
  PWM_SetCompare(1,15);//90
  PWM_SetCompare(4,15);//90  
    Delay_ms(200);
		if(Act_mode != 0x05) break;
	}
}
void Act_TurnL()//左转
{
 while(Act_mode == 0x06)
	{
	PWM_SetCompare(1,20);//135
  PWM_SetCompare(4,20);//135
		Delay_ms(200);
		if(Act_mode != 0x06) break;
  PWM_SetCompare(2,10);//45
  PWM_SetCompare(3,10);//45  
	  Delay_ms(200);
		if(Act_mode != 0x06) break;
  PWM_SetCompare(1,15);//90
  PWM_SetCompare(4,15);//90 
    Delay_ms(200);
		if(Act_mode != 0x06) break;
  PWM_SetCompare(2,15);//90
  PWM_SetCompare(3,15);//90  
    Delay_ms(200);
		if(Act_mode != 0x06) break;
	}
}

void Act_HandShake()//握手
{ 
	PWM_SetCompare(1,15);//90
  PWM_SetCompare(3,10);//45
  PWM_SetCompare(4,20);//135
 while(Act_mode == 0x07)
	{
   PWM_SetCompare(2,20);//135
		PWM_SetCompare(0,10);//45
		Delay_ms(400);
		if(Act_mode != 0x07) break;
	 PWM_SetCompare(2,25);//180
	 PWM_SetCompare(0,20);//135
		Delay_ms(400);
		if(Act_mode != 0x07) break;
	}
}

void Act_Lie(void)//躺
{
  PWM_SetCompare(1,25);//-180
  PWM_SetCompare(2,5);//-0
  PWM_SetCompare(3,5);//-0
  PWM_SetCompare(4,25);//-180
}
void Act_BodyShake()//身体摇摆
{
  while(Act_mode == 0x09)
	{
	PWM_SetCompare(1,10);//45
	PWM_SetCompare(2,20);//135
  PWM_SetCompare(3,10);//45 
	PWM_SetCompare(4,20);//135
		Delay_ms(300);
		if(Act_mode != 0x09) break;
  PWM_SetCompare(1,20);//135 
	PWM_SetCompare(2,10);//45
  PWM_SetCompare(3,20);//135
  PWM_SetCompare(4,10);//45
    Delay_ms(300);
		if(Act_mode != 0x09) break;
	}

}

void Act_Turn()//转圈
{
 while(Act_mode == 0x10)
	{
	PWM_SetCompare(1,20);//135
  PWM_SetCompare(4,20);//135
		Delay_ms(150);
		if(Act_mode != 0x10) break;
  PWM_SetCompare(2,10);//45
  PWM_SetCompare(3,10);//45  
	  Delay_ms(150);
		if(Act_mode != 0x10) break;
  PWM_SetCompare(1,15);//90
  PWM_SetCompare(4,15);//90 
    Delay_ms(150);
		if(Act_mode != 0x10) break;
  PWM_SetCompare(2,15);//90
  PWM_SetCompare(3,15);//90  
    Delay_ms(150);
		if(Act_mode != 0x10) break;
	}
}

void Act_Stretch(void)//伸懒腰
{
  PWM_SetCompare(1,5);//-0
  PWM_SetCompare(2,25);//-180
  PWM_SetCompare(3,10);//-45
  PWM_SetCompare(4,20);//-135
}
void Face(const uint8_t *bmp)
{
 
 OLED_ShowImage(0,0,128,64,bmp);
 OLED_Update();
}
void Act_Cmd()
{

 switch(Act_mode)
 {
	 case 0x01: s_1 = 0;Face(Stand);Act_Stand();while(Act_mode == 0x01){};break;
	 case 0x02: s_1 = 0;Face(Sit);Act_Sit();while(Act_mode == 0x02){};break;
	 case 0x03: s_1 = 0;Face(Astrive);Act_Stand();Delay_ms(200);Act_Advance();break;
	 case 0x04: s_1 = 0;Face(Bstrive);Act_Stand();Delay_ms(200);Act_Back();break;
	 case 0x05: s_1 = 0;Face(TurnR);Act_Stand();Delay_ms(200);Act_TurnR();break;
	 case 0x06: s_1 = 0;Face(TurnL);Act_Stand();Delay_ms(200);Act_TurnL();break;
	 case 0x07: s_1 = 0;Face(Shake);Act_Stand();Delay_ms(200);Act_HandShake();break;
	 case 0x08: s_1 = 0;Face(Actinit);Act_Lie();while(Act_mode == 0x08){};break;
	 case 0x09: s_1 = 0;Face(Lie);Act_Stand();Delay_ms(200);Act_BodyShake();break;
	 case 0x10: s_1 = 0;Face(Turn);Act_Stand();Delay_ms(200);Act_Turn();break;
	 case 0x11: s_1 = 0;Act_Stand();Face(Stand);Delay_ms(500);Act_Stretch();Delay_ms(250);Face(Lie);Delay_ms(2000);Act_mode = 0x01;break;
   default: ;
 }
}

#include "stm32f10x.h"                  // Device header


#ifndef _PWM_H
extern uint16_t s_1;
void PWM_Init(void);
void PWM_SetCompare(uint8_t n,uint8_t Compare);
#define _PWM_H
#endif

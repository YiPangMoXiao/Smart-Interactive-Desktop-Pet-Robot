#include "stm32f10x.h"                  // Device header
             
#include "Act.h"                  // Device header  

uint8_t ms_20 = 0;
uint16_t s_1 = 0;

void PWM_Init()
{
 //开启时钟
 RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3 | RCC_APB1Periph_TIM4,ENABLE);
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB,ENABLE);
	
 GPIO_InitTypeDef GPIO_InitStruct;	
 //配置GPIOA
 GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
 GPIO_InitStruct.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 ;
 GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
 GPIO_Init(GPIOA,&GPIO_InitStruct);
	//配置GPIOB
 GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
 GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_6;
 GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
 GPIO_Init(GPIOB,&GPIO_InitStruct);
 //配置时钟源
 TIM_InternalClockConfig(TIM3);
 TIM_InternalClockConfig(TIM4);
 //配置时基
 TIM_TimeBaseInitTypeDef TIM_BaseInitStruct;
 TIM_BaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
 TIM_BaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
 TIM_BaseInitStruct.TIM_Period = 200;//20ms
 TIM_BaseInitStruct.TIM_Prescaler = 7200;
 TIM_BaseInitStruct.TIM_RepetitionCounter = 0;
 TIM_TimeBaseInit(TIM4,&TIM_BaseInitStruct);
 TIM_TimeBaseInit(TIM3,&TIM_BaseInitStruct);
 
 	TIM_ClearFlag(TIM4, TIM_FLAG_Update);						//清除定时器更新标志位
	TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);					//开启TIM4的更新中断
		/*NVIC配置*/
	NVIC_InitTypeDef NVIC_InitStructure;						//定义结构体变量
	NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;				//选择配置NVIC的TIM4线
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;				//指定NVIC线路使能
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;	//指定NVIC线路的抢占优先级为2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;			//指定NVIC线路的响应优先级为2
	NVIC_Init(&NVIC_InitStructure);								//将结构体变量交给NVIC_Init，配置NVIC外设
	
 //输出比较初始化
 TIM_OCInitTypeDef TIM_OCInitStruct;
 TIM_OCStructInit(&TIM_OCInitStruct);
 TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;
 TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;
 TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
 TIM_OCInitStruct.TIM_Pulse = 0;
 TIM_OC1Init(TIM3,&TIM_OCInitStruct);
 TIM_OC2Init(TIM3,&TIM_OCInitStruct);
 TIM_OC3Init(TIM3,&TIM_OCInitStruct);
 TIM_OC4Init(TIM3,&TIM_OCInitStruct);
 
 TIM_OC1Init(TIM4,&TIM_OCInitStruct);
 //开启定时器3/4
 TIM_Cmd(TIM4,ENABLE);
 TIM_Cmd(TIM3,ENABLE);
}

void PWM_SetCompare(uint8_t n,uint8_t Compare)
{
 switch(n)
 {
	 case 0:TIM_SetCompare1(TIM4,Compare);break;
	 
	 case 1:TIM_SetCompare1(TIM3,Compare);break; 
   case 2:TIM_SetCompare2(TIM3,Compare);break; 
   case 3:TIM_SetCompare3(TIM3,Compare);break; 
   case 4:TIM_SetCompare4(TIM3,Compare);break;	 
   default: ;
 }
}

void TIM4_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM4, TIM_IT_Update) == SET)
	{
		if(Act_mode != 0x20) ms_20 ++;
		if(ms_20 == 50) 
		{
			ms_20 = 0;
		 s_1 ++;//1s
		}
		
		if(s_1 == 300) 
		{
		  Act_mode = 0x20;
			s_1 = 0;
		}
		
		
		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
	}
}

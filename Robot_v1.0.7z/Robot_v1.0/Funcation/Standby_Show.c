#include "stm32f10x.h"                  // Device header
#include "Standby_Show.h"                  // Device header
            
 uint8_t temp,humi;
 void Standby_Init(void)
 {
  DHT11_Start();
	DS1302_Init();

 }

 void Standby_OLEDShow(void)
 {
   DS1302_ShowTime();
	 DHT11_OLED(&temp,&humi);
 }
 
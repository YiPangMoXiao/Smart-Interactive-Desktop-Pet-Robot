#include "stm32f10x.h"                  // Device header
#include "PWM.h"
#include "DELAY.h"
#include "OLED.H"
#ifndef _ACT_H
#define _ACT_H
extern uint8_t Act_mode ;
void Act_Init(void);
void Act_Cmd(void);
void Face(const uint8_t *bmp);
void Act_Lie(void);
void Act_Stretch(void);
void Act_Stand(void);
#endif
